<?php 
session_start();
if (!isset($_SESSION['username'])) 
{
  header('location:http://localhost/login_ex/login_logout/loginForm.php');
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Book Record Managemnnt/Insertion Form</title>
<link rel="stylesheet" type="text/css" href="./css/brmcss.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<?php include_once "header.php" ?>

<div class="topnav">
  <a href="index.php">Home</a>
  
  <a href="#">About</a>
   <a style="float:right;" href="logout.php">Logout</a>
</div>

<div class="row">
  <div class="column side">
    <h3>Add New Book</h3>
  
    <div class="link">
 <a href="./insertionForm1.php"> Insert</a>
 <a href="./view1.php"> view</a>
 <a href="./deleteForm1.php"> Delete</a>
 <a href="./updateForm1.php"> Update</a>
    </div>

  </div>
  
  <div class="column middle">
    <h2>Insert Book Details</h2>
  	<form action="insertion1.php" method="post">
		<table>
			<tr>
				<th>Title</th>
				<td><input type="text" name="title" placeholder="Enter title" required="true"/> </td>
			</tr>
			<tr>
				<th>Price</th>
				<td><input type="text" name="price" placeholder="Enter price" required="true"/> </td>
			</tr>
			<tr>
				<th>Author</th>
				<td><input type="text" name="author" placeholder="Enter Author" required="true"/> </td>
			</tr>

			<tr>
				<th>Pages</th>
				<td><input type="text" name="pages" placeholder="Enter Page" required="true"/> </td>
			</tr>
			<tr>
				<th></th>
				<td><input type="submit" value="Insert" required="true"/> </td>
			</tr>
		</table>
		
	</form>

  </div>
  
  <div class="column side">
    <h2><?php  echo $_SESSION['username'];?></h2>
    <p>Hello-<?php  echo $_SESSION['username'];?> 
	<br>	Your Profile</p>
  </div>
</div>

 <?php include_once "footer.php" ?>
  
</body>
</html>
