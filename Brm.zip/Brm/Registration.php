<?php
$username=$_POST['username'];
$password=$_POST['password'];
$Unickname=$_POST['Unickname'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$address=$_POST['address'];

$table_book=$_POST['username']."_book";

$con=mysqli_connect('localhost','root'); //connection id addres and database user name and password
mysqli_select_db($con,'logindb'); // 1st pass connection object and database name like 
$ch="Select * from user where username='$username'";

$q2="create table $table_book ( bookid int(5) primary key auto_increment,title varchar(20) not null,price float(7.2) not null ,author varchar(20) ,pages int(5) )";


$record=mysqli_query($con,$ch);
$num=mysqli_num_rows($record);


if($num==1)
{
   echo "Username Already Exist"; 
}

else
{
  
   $q= "insert into user (username,password,umail,Mob,uadd,Unickname) values('$username','$password','$email',$mobile,'$address','$Unickname')";//Number not write into single coates
     
     if (mysqli_query($con,$q))
           {echo "Registered";
                    if (mysqli_query($con,$q2))
                    {   $q= "insert into $table_book (title,price,author,pages) values('c++',800,'demo',300)";  }
                   else
                     {echo "not create table";}

        }

    else
        {echo "not Registered";}


      echo "Account Created";


    }
mysqli_close($con);
?>

  <!DOCTYPE html>
  <html>
  <head>
    <title>Registration process</title>
  </head>
  <body>
  <h1>Employee Management </h1>
  <p>    
  </p>
   <a href="loginForm.php">GotoLogin</a>
  </body>
  </html>
