<!DOCTYPE html>
<html lang="en">
<head>
<title>Brm/Register></title>
<link rel="stylesheet" type="text/css" href="./css/brmcss.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<?php include_once "header.php" ?>

<div class="topnav">
  <a href="MyHome1.php">Home</a>
  <a href="loginForm.php">Login</a>
  <a href="#">About</a>
   <a style="float:right;" href="#">Logout</a>
</div>

<div class="row">
  <div class="column side">
    <h3>Add New Book</h3>
  

  </div>
  
  <div class="column middle">
  	<h1>Create Account </h1>
 
<form action="Registration.php" method="post">

		<h3> Create Account in BRM</h3>
		<table class="RegisterTable">
			<tr>
				<td>Username</td>
				<td><input type="text" name="username" required="true" maxlength="10"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="text" name="password" required="true" maxlength="10"></td>
			</tr>
			<tr>
				<td>Nick name</td>
				<td><input type="text" name="Unickname" required="true"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="email" name="email" required="true"></td>
			</tr>
			<tr>
				<td>Mobile Number</td>
				<td><input type="text" name="mobile" required="true"></td>
			</tr>
			<tr>
				<td>Address-only state</td>
				<td><input list="address" name="address" required>
					<datalist id="address">
						<option value="Jharkhand">
						<option value="Bihar">
						<option value="Up">
						<option value="WestBengal">
						<option value="Oddisa">
						<option value="AndhraPardes">
						<option value="maharastra">
						<option value="Gujrat">
						<option value="TamilNadu">
						<option value="kerala">
					</datalist>

				</td>
			</tr>
			

			<tr >
				
				
				<td><a href="loginForm.php" ><input type="button" value="Login "  class="RegisterSubmit"></a> 
				</td>
					<td>
						<input type="submit" value="Register" class="RegisterSubmit">
					</td>
			</tr>
			
			
		</table>

	
</form>
  
  </div>
  
  <div class="column side">




  </div>
</div>



 <?php include_once "footer.php" ?>
  
</body>
</html>
