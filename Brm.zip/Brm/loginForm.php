
<!DOCTYPE html>
<html>
<head>
	<title>login User</title>
	<style type="text/css">
		
		input 
		{
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
}
input[type=button]:hover
{
background-color: #333;
  color: red;	
}
input[type=submit]:hover
{
background-color: #333;
  color: red;	
}
/* Style the submit button */
input[type=submit] {
  background-color: #333;
  color: white;
}
input[type=button] {
  background-color: #333;
  color: white;
}
input[type=button] {
  background-color: #333;
  color: white;
}

table
{
margin-left: 15px;
}
body
{
  background-color: #3331;
}
/* Style the container for inputs */
.container {
  background-color: #f1f1f1;
  padding: 20px;
  width: 30%;
    margin-left: 35%;

    border-radius: 10px;
    margin-top: 20px;
}
h2
{
	text-align: center;
	color: #333
}
label
{
	font-size: 20px;
}

</style>
</head>
<body>
	<div class="container">

<form action="validation.php" method="post">

		
		<div class="head">	 </div>
		<div class="table">
		
				<h2> Book Record Management</h2>
				 <label for="username">Username</label>
					<input type="text" name="username" required="true" maxlength="10">
			
			  <label for="password">Password</label>
				
				
					<input type="password" name="password" required="true" maxlength="10">
			
				<input type="submit" value="Login">
		</div>
		</form>
		<a href="./Register.php"><input type="button" value="Register"></a>
        <a href="#"><abbr title="This is ligin for Administration"><input type="button" value="AdminLogin"></abbr></a>
    </div>
</body>
</html>