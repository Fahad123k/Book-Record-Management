<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="./css/brmcss.css">
<style type="text/css">

	
</style>

</head>
<body>
<div class="footer">
	<p>© Copyright 2020-2021<br> www.Brm.com. All rights reserved. Developed by Fahad

	</p>
</div>
	
</body>
</html>