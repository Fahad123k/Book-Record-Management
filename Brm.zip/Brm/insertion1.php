<?php 
session_start();
if (!isset($_SESSION['username'])) 
{
  header('location:http://localhost/login_ex/login_logout/loginForm.php');
}

?>



<?php
$title=$_POST['title'];
$price=$_POST['price'];
$author=$_POST['author'];
$pages=$_POST['pages'];

$table_book=$_SESSION['username']."_book";

$con=mysqli_connect('localhost','root'); //connection id addres and database user name and password
mysqli_select_db($con,'logindb'); // 1st pass connection object and database name like 
$q= "insert into $table_book (title,price,author,pages) values('$title',$price,'$author','$pages')";//Number not write into single coates
$status=mysqli_query($con,$q);
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Book Record Managemnnt/Insertion Form</title>
<link rel="stylesheet" type="text/css" href="./css/brmcss.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<?php include_once "header.php" ?>

<div class="topnav">
  <a href="index.php">Home</a>

  <a href="#">About</a>
   <a style="float:right;" href="logout.php">Logout</a>
</div>

<div class="row">
  <div class="column side">
    <h3>Add New Book</h3>
  
    <div class="link">
 <a href="./insertionForm1.php"> Insert</a>
 <a href="./view1.php"> view</a>
 <a href="./deleteForm1.php"> Delete</a>
 <a href="./updateForm1.php"> Update</a>
    </div>

  </div>
  
  <div class="column middle">
    <h2>Insertion Details</h2>
	
    		<p>    <?php
				if($status==1) echo "Record inserted";
				else echo "Insertion Failed";  
			 ?> 
	</p>
	 Do you want to more insertion <a href="insertionForm1.php">Click here</a>
  </div>
  
  <div class="column side">
    <h2><?php  echo $_SESSION['username'];?></h2>
    <p>Hello-<?php  echo $_SESSION['username'];?> 
  <br>  Your Profile</p>
  </div>
</div>

 <?php include_once "footer.php" ?>
  
</body>
</html>

