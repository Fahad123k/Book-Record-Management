<?php
session_start();

$username=$_POST['username'];
$password=$_POST['password'];

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'logindb');

$q="Select * from user where username='$username' && password='$password'";
$record=mysqli_query($con,$q);
$num=mysqli_num_rows($record);
if($num==1)
{
$_SESSION['username']=$username;


	# code...

/*$_SESSION['Unickname']=$Unickname;
$_SESSION['mobile']=$mobile;
$_SESSION['address']=$address;
$_SESSION['email']=$email;*/
header('location:http://localhost/login_ex/login_logout/index.php');
}
else
{  
	
header('location:http://localhost/login_ex/login_logout/loginForm.php');
}
?>