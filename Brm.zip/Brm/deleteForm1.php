
<?php 
session_start();
if (!isset($_SESSION['username'])) 
{
  header('location:http://localhost/login_ex/login_logout/loginForm.php');
}

?>


<?php
$table_book=$_SESSION['username']."_book";
$con=mysqli_connect('localhost','root');

mysqli_select_db($con,'logindb');
$q="select * from $table_book";
$result=mysqli_query($con,$q);//coonection obeject and query objectand return associatve 2D-array
$num=mysqli_num_rows($result);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="./css/brmcss.css">
<title>Book Record Managemnnt/Insertion Form</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<?php include_once "header.php" ?>

<div class="topnav">
  <a href="index.php">Home</a>
  
  <a href="#">About</a>
   <a style="float:right;" href="#">Logout</a>
</div>

<div class="row">
  <div class="column side">
    <h3>Add New Book</h3>
  
    <div class="link">
 <a href="./insertionForm1.php"> Insert</a>
 <a href="./view1.php"> view</a>
 <a href="./deleteForm1.php"> Delete</a>
 <a href="./updateForm1.php"> Update</a>
    </div>

  </div>
  
  <div class="column middle">
    <h2>Delete Book Details</h2>
	 <form action="deletion1.php" method="post">
	<table class="table1">
		<tr>
			<th class="headTable" >Book-Id</th>
			<th class="headTable">Title</th>
			<th class="headTable">Price</th>
			<th class="headTable">Author</th>
			<th class="headTable">Pages</th>
			<th class="headTable"> Select to delete</th>
		</tr>
		<?php
		for($i=1;$i<=$num;$i++)
		{
			$row=mysqli_fetch_array($result);// fetch first 1D-array
			?>
			<tr class="tableRow">

				<td><?php echo $row['bookid']; ?></td>
				<td><?php echo $row['title']; ?></td>
				<td><?php echo $row['price']; ?></td>
				<td><?php echo $row['author']; ?></td>
				<td><?php echo $row['pages']; ?></td>
				<td><input type="checkbox"  value="<?php echo $row['bookid']; ?>" name="num[]"< /td>
			</tr tableRow>


			<?php
		}
		?>
		<tr >
			<td colspan="5"> <input type="submit" value="Delete"/ name="submit1"> </td>
		</tr>
	
	</table>
	<?php
	if($num==0)
	echo "Record is empty";
{
		if(isset($_POST["submit1"]))
	 {
 		 $box=$_POST['num'];
 		 while (list($key,$val)=@each($box)) 
 		 {

 	 		 $q="delete  from book where bookid=$val";
			mysqli_query($con,$q);

 		 }
 	?>
		<script type="text/javascript">
			window.location.href=window.location.href;
	
		</script>
	
	<?php
	}
}







mysqli_close($con);
?>

  </div>
  
  <div class="column side">
    <h2><?php  echo $_SESSION['username'];?></h2>
    <p>Hello-<?php  echo $_SESSION['username'];?> 
	<br>	Your Profile</p>
  </div>
</div>

 <?php include_once "footer.php" ?>
  
</body>
</html>
