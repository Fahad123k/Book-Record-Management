<?php 
session_start();
if (!isset($_SESSION['username'])) 
{
  header('location:http://localhost/login_ex/login_logout/loginForm.php');
}

?>


<?php
$table_book=$_SESSION['username']."_book";

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'logindb');
$size=sizeof($_POST);
$records=$size/5;
for($i=1;$i<=$records;$i++)
{
	$Iindex="bookid".$i;
	$bookid[$i]=$_POST[$Iindex];
	$Tindex="title".$i;
	$title[$i]=$_POST[$Tindex];
	$Pindex="price".$i;
	$price[$i]=$_POST[$Pindex];
	$Aindex="author".$i;
	$author[$i]=$_POST[$Aindex];
}

for($i=1;$i<=$records;$i++)
{
	$qr="update $table_book SET title='$title[$i]',price='$price[$i]',author='$author[$i]'
	 where bookid=$bookid[$i]";
	mysqli_query($con,$qr);
}
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Book Record Managemnnt/Insertion Form</title>
<link rel="stylesheet" type="text/css" href="./css/brmcss.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<?php include_once "header.php" ?>

<div class="topnav">
  <a href="index.php">Home</a>
  <a href="#">Login</a>
  <a href="#">About</a>
   <a style="float:right;" href="logout.php">Logout</a>
</div>

<div class="row">
  <div class="column side">
    <h3>Add New Book</h3>
  
    <div class="link">
 <a href="./insertionForm1.php"> Insert</a>
 <a href="./view1.php"> view</a>
 <a href="./deleteForm1.php"> Delete</a>
 <a href="./updateForm1.php"> Update</a>
    </div>

  </div>
  
  <div class="column middle">
    <h2>Record Updation</h2>
    
	<p>  <?php echo "Record updated";?> </p>
	 Do you want to more update <a href="updateForm1.php">Click here</a>
  </div>
  
  <div class="column side">
    <h2><?php  echo $_SESSION['username'];?></h2>
    <p>Hello-<?php  echo $_SESSION['username'];?> 
  <br>  Your Profile</p>
  </div>
</div>
 <?php include_once "footer.php" ?>
</body>
</html>