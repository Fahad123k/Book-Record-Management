<?php
session_start();
session_destroy();
header('location:http://localhost/login_ex/login_logout/loginForm.php');
?>